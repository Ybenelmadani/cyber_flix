import React from "react";

export default function NavDropdown({ genres = [], onSelect }) {
  if (!Array.isArray(genres) || genres.length === 0) {
    return null;
  }

  return (
    <div className="absolute top-full left-0 mt-2 min-w-56 max-h-72 overflow-y-auto bg-cyber-darker border border-cyber-cyan/30 rounded-xl p-2 shadow-lg z-40">
      {genres.map((genre) => (
        <button
          key={genre.id}
          type="button"
          onClick={() => onSelect && onSelect(genre)}
          className="w-full text-left cursor-pointer py-2 px-3 hover:bg-cyber-cyan/10 rounded-lg text-cyber-cyan"
        >
          {genre.name}
        </button>
      ))}
    </div>
  );
}
