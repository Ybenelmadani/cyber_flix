import React from "react";

export default function Footer({ text = "(c) 2026 CYBERFLIX - All rights reserved" }) {
  return (
    <footer className="mt-16 py-6 text-center border-t border-cyber-cyan/20 text-cyber-cyan/40">{text}</footer>
  );
}