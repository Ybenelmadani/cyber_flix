import React from "react";
import MovieCard from "./MovieCard";

function GridSkeleton() {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
      {Array.from({ length: 10 }).map((_, idx) => (
        <div key={idx} className="animate-pulse">
          <div className="aspect-[2/3] rounded-2xl bg-cyber-darker border border-cyber-cyan/10 mb-3" />
          <div className="h-4 rounded bg-cyber-darker/80 mb-2" />
          <div className="h-3 w-2/3 rounded bg-cyber-darker/80" />
        </div>
      ))}
    </div>
  );
}

export default function MovieGrid({
  movies = [],
  onSelect,
  isLoading = false,
  emptyMessage = "No movies to display.",
  detailBasePath = "movie",
  movieCardLabels,
}) {
  if (isLoading) {
    return <GridSkeleton />;
  }

  if (!Array.isArray(movies) || movies.length === 0) {
    return <p className="text-cyber-cyan/70">{emptyMessage}</p>;
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
      {movies.map((movie) => (
        <MovieCard
          key={movie.id}
          movie={movie}
          onClick={() => onSelect && onSelect(movie)}
          href={`/${detailBasePath}/${movie.id}`}
          yearLabel={movieCardLabels?.yearLabel}
          unavailableLabel={movieCardLabels?.unavailableLabel}
        />
      ))}
    </div>
  );
}
