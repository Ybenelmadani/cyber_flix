import React from "react";

export default function AdBanner({ hidden = false, label = "Advertisement" }) {
  if (hidden) {
    return null;
  }

  return (
    <div className="my-6 rounded-2xl border border-cyber-cyan/20 bg-cyber-darker/40 p-4 text-center">
      <p className="text-xs tracking-wide uppercase text-cyber-cyan/60">{label}</p>
      <div className="mt-3 h-24 rounded-xl border border-dashed border-cyber-cyan/20 flex items-center justify-center text-cyber-cyan/70">
        Ad Slot 970x90 / 728x90
      </div>
    </div>
  );
}

