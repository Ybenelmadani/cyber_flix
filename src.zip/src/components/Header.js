import React, { useEffect, useRef, useState } from "react";
import NavDropdown from "./NavDropdown";

export default function Header({
  searchQuery,
  setSearchQuery,
  genres = [],
  onGenreSelect,
  genreLabel = "Genres",
  searchPlaceholder = "Search for a movie...",
  languageSwitchLabel = "FR",
  onToggleLanguage = () => {},
  user = null,
  labels = {},
  onOpenAuth = () => {},
  onLogout = () => {},
  onUpgrade = () => {},
}) {
  const [showDropdown, setShowDropdown] = useState(false);
  const menuRef = useRef(null);

  useEffect(() => {
    const handleOutsideClick = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setShowDropdown(false);
      }
    };

    const handleEscape = (event) => {
      if (event.key === "Escape") {
        setShowDropdown(false);
      }
    };

    document.addEventListener("mousedown", handleOutsideClick);
    document.addEventListener("keydown", handleEscape);

    return () => {
      document.removeEventListener("mousedown", handleOutsideClick);
      document.removeEventListener("keydown", handleEscape);
    };
  }, []);

  const handleGenreSelect = (genre) => {
    if (onGenreSelect) {
      onGenreSelect(genre);
    }
    setShowDropdown(false);
  };

  return (
    <header className="bg-cyber-dark border-b border-cyber-cyan/20 p-4 relative z-30">
      <div className="flex flex-col gap-3 md:gap-4">
        <div className="flex items-center justify-between gap-4">
          <div className="relative flex items-center gap-3" ref={menuRef}>
            <button
              type="button"
              onClick={() => setShowDropdown((prev) => !prev)}
              className="text-cyber-cyan font-bold hover:text-cyber-fuchsia transition"
              aria-expanded={showDropdown}
              aria-haspopup="menu"
            >
              {genreLabel}
            </button>

            <button
              type="button"
              onClick={onToggleLanguage}
              className="px-3 py-1 rounded-lg border border-cyber-cyan/30 text-cyber-cyan text-sm hover:border-cyber-fuchsia hover:text-cyber-fuchsia transition"
              aria-label="Switch language"
            >
              {languageSwitchLabel}
            </button>

            {showDropdown ? <NavDropdown genres={genres} onSelect={handleGenreSelect} /> : null}
          </div>

          <div className="flex items-center gap-2">
            {user ? (
              <>
                {user.plan !== "premium" ? (
                  <button
                    type="button"
                    onClick={onUpgrade}
                    className="px-3 py-1 rounded-lg border border-amber-300/50 text-amber-200 text-xs hover:bg-amber-500/10"
                  >
                    {labels.upgrade || "Go Premium"}
                  </button>
                ) : (
                  <span className="px-2 py-1 rounded bg-emerald-500/20 text-emerald-200 text-xs">
                    {labels.premium || "Premium"}
                  </span>
                )}
                <button
                  type="button"
                  onClick={onLogout}
                  className="px-3 py-1 rounded-lg border border-cyber-cyan/30 text-cyber-cyan text-xs hover:border-cyber-fuchsia hover:text-cyber-fuchsia transition"
                >
                  {labels.logout || "Logout"}
                </button>
              </>
            ) : (
              <button
                type="button"
                onClick={onOpenAuth}
                className="px-3 py-1 rounded-lg border border-cyber-cyan/30 text-cyber-cyan text-xs hover:border-cyber-fuchsia hover:text-cyber-fuchsia transition"
              >
                {labels.login || "Login"}
              </button>
            )}

            <h1 className="text-xl md:text-2xl font-bold text-cyan-400 whitespace-nowrap">CYBERFLIX</h1>
          </div>
        </div>

        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder={searchPlaceholder}
          className="w-full md:max-w-md md:self-center bg-cyber-darker border border-cyber-cyan/30 rounded-xl px-4 py-2 text-cyber-cyan placeholder-cyber-cyan/50"
        />
      </div>
    </header>
  );
}
