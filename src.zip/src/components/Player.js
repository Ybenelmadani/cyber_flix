import React from 'react';
import { Play } from 'lucide-react';

export default function Player({ servers, activeServer, setActiveServer }) {
  return (
    <div className="bg-cyber-darker border border-cyber-cyan/30 rounded-2xl overflow-hidden">
      <div className="flex overflow-x-auto bg-cyber-darker/80 border-b border-cyber-cyan/20 scrollbar-hide">
        {servers.map(server => (
          <button
            key={server}
            onClick={() => setActiveServer(server)}
            className={`px-6 py-4 font-medium whitespace-nowrap transition-all ${activeServer === server ? 'server-active' : 'text-cyber-cyan/70 hover:text-cyber-cyan hover:bg-cyber-cyan/5'}`}
          >
            {server}
          </button>
        ))}
      </div>
      <div className="aspect-video flex items-center justify-center bg-cyber-dark">
        <div className="text-center group cursor-pointer">
          <div className="w-20 h-20 bg-cyber-gradient rounded-full flex items-center justify-center shadow-lg shadow-cyber-fuchsia/30 group-hover:scale-110 transition-transform">
            <Play className="w-10 h-10 text-white fill-white mr-1" />
          </div>
        </div>
      </div>
    </div>
  );
}
