import React from "react";

export default function Genres({ genres = [], onSelect, title = "Filter by genre" }) {
  if (!Array.isArray(genres) || genres.length === 0) {
    return null;
  }

  return (
    <div className="mt-10">
      <h2 className="text-xl font-bold mb-4">{title}</h2>
      <div className="flex flex-wrap gap-4">
        {genres.map((genre) => (
          <button
            key={genre.id}
            type="button"
            onClick={() => onSelect && onSelect(genre)}
            className="border border-cyber-cyan px-4 py-2 rounded-xl hover:bg-cyber-cyan/10"
          >
            {genre.name}
          </button>
        ))}
      </div>
    </div>
  );
}