import React from "react";

const getTrailer = (videos) => {
  const results = videos?.results || [];
  return (
    results.find((v) => v.site === "YouTube" && v.type === "Trailer") ||
    results.find((v) => v.site === "YouTube") ||
    null
  );
};

export default function MovieDetail({
  mediaType = "movie",
  movie,
  seasonDetails,
  watchProviders,
  providerCountry,
  onProviderCountryChange,
  selectedSeason,
  onSeasonSelect,
  onBack,
  onToggleFavorite,
  isFavorite,
  isLoading,
  labels,
}) {
  if (!movie) {
    return null;
  }

  const text = labels || {};
  const naText = text.na || "N/A";
  const title = movie.title || movie.name;
  const releaseDate = movie.release_date || movie.first_air_date;
  const posterUrl = movie.poster_path
    ? `https://image.tmdb.org/t/p/w500${movie.poster_path}`
    : "https://via.placeholder.com/400x600?text=No+Image";

  const trailer = getTrailer(movie?.videos);
  const providersByCountry = watchProviders?.[providerCountry] || null;
  const providerGroups = [
    { key: "flatrate", label: text.stream || "Streaming" },
    { key: "rent", label: text.rent || "Rent" },
    { key: "buy", label: text.buy || "Buy" },
    { key: "free", label: text.free || "Free" },
  ];

  return (
    <div className="animate-in fade-in duration-500 space-y-6">
      <div className="mb-4 flex flex-wrap gap-3">
        <button onClick={onBack} className="btn-cyber px-4 py-2 text-sm">
          {text.back || "Back"}
        </button>
        <button
          type="button"
          onClick={onToggleFavorite}
          className="px-4 py-2 text-sm rounded-xl border border-cyber-cyan/30 text-cyber-cyan hover:border-cyber-fuchsia hover:text-cyber-fuchsia transition"
        >
          {isFavorite ? text.removeFavorite || "Remove Favorite" : text.addFavorite || "Add Favorite"}
        </button>
      </div>

      {isLoading ? <p className="text-cyber-cyan/70">{text.loading || "Loading details..."}</p> : null}

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="card-neon p-6 lg:col-span-1">
          <img src={posterUrl} alt={title} className="w-full rounded-xl mb-4 shadow-lg shadow-cyber-cyan/10" />
          <h1 className="text-2xl font-bold text-cyber-cyan">{title}</h1>
          <p className="text-cyber-cyan/70 mt-2">{movie.overview || text.noOverview || "No overview available."}</p>
          <div className="mt-4 text-cyber-cyan/70 space-y-1">
            <p>
              {text.year || "Year"}: {releaseDate?.split("-")[0] || naText}
            </p>
            <p>
              {text.rating || "Rating"}: {movie.vote_average ?? naText}
            </p>
            <p>
              {text.runtime || "Runtime"}: {movie.runtime ? `${movie.runtime} ${text.minutes || "min"}` : naText}
            </p>
            {mediaType === "tv" ? (
              <>
                <p>
                  {text.seasons || "Seasons"}: {movie.number_of_seasons ?? naText}
                </p>
                <p>
                  {text.episodes || "Episodes"}: {movie.number_of_episodes ?? naText}
                </p>
              </>
            ) : null}
          </div>
        </div>

        <div className="card-neon p-6 lg:col-span-2 space-y-5">
          <h2 className="text-xl font-bold text-cyber-cyan">{text.info || "Information"}</h2>
          <div className="grid md:grid-cols-2 gap-4 text-cyber-cyan/80">
            <p>
              {text.status || "Status"}: {movie.status || naText}
            </p>
            <p>
              {text.language || "Language"}: {movie.original_language || naText}
            </p>
            <p>
              {text.popularity || "Popularity"}: {movie.popularity ?? naText}
            </p>
            <p>
              {text.votes || "Votes"}: {movie.vote_count ?? naText}
            </p>
          </div>

          {Array.isArray(movie.genres) && movie.genres.length > 0 ? (
            <div className="flex flex-wrap gap-2">
              {movie.genres.map((genre) => (
                <span
                  key={genre.id}
                  className="px-3 py-1 rounded-full bg-cyber-cyan/10 border border-cyber-cyan/30 text-cyber-cyan text-sm"
                >
                  {genre.name}
                </span>
              ))}
            </div>
          ) : null}

          <div>
            <h3 className="font-semibold text-cyber-cyan mb-3">{text.watchNow || "Watch now"}</h3>
            {trailer ? (
              <div className="aspect-video rounded-xl overflow-hidden border border-cyber-cyan/20">
                <iframe
                  title="trailer"
                  width="100%"
                  height="100%"
                  src={`https://www.youtube.com/embed/${trailer.key}`}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              </div>
            ) : (
              <p className="text-cyber-cyan/70">{text.noTrailer || "No trailer available for this title."}</p>
            )}
          </div>

          <div>
            <h3 className="font-semibold text-cyber-cyan mb-3">{text.watchProviders || "Where to watch"}</h3>
            <div className="flex items-center gap-2 mb-3">
              <span className="text-cyber-cyan/80 text-sm">{text.providerCountry || "Country"}:</span>
              {["MA", "FR", "US"].map((countryCode) => (
                <button
                  key={countryCode}
                  type="button"
                  onClick={() => onProviderCountryChange && onProviderCountryChange(countryCode)}
                  className={`px-2 py-1 rounded border text-xs ${
                    providerCountry === countryCode
                      ? "border-cyber-fuchsia text-cyber-fuchsia bg-cyber-fuchsia/10"
                      : "border-cyber-cyan/30 text-cyber-cyan"
                  }`}
                >
                  {countryCode}
                </button>
              ))}
            </div>

            {providersByCountry ? (
              <div className="space-y-3">
                {providerGroups.map((group) =>
                  Array.isArray(providersByCountry[group.key]) && providersByCountry[group.key].length > 0 ? (
                    <div key={group.key}>
                      <p className="text-cyber-cyan/80 text-sm mb-2">{group.label}</p>
                      <div className="flex flex-wrap gap-2">
                        {providersByCountry[group.key].map((provider) => (
                          <div
                            key={`${group.key}-${provider.provider_id}`}
                            className="flex items-center gap-2 px-2 py-1 rounded-lg border border-cyber-cyan/20 bg-cyber-darker/40"
                          >
                            {provider.logo_path ? (
                              <img
                                src={`https://image.tmdb.org/t/p/w92${provider.logo_path}`}
                                alt={provider.provider_name}
                                className="w-6 h-6 rounded object-cover"
                              />
                            ) : null}
                            <span className="text-xs text-cyber-cyan">{provider.provider_name}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : null
                )}
                {providersByCountry.link ? (
                  <a
                    href={providersByCountry.link}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-block mt-1 text-xs text-cyber-fuchsia hover:underline"
                  >
                    TMDB watch link
                  </a>
                ) : null}
              </div>
            ) : (
              <p className="text-cyber-cyan/70">{text.noProvidersCountry || "No official providers found for this country."}</p>
            )}
          </div>
        </div>
      </div>

      {mediaType === "tv" && Array.isArray(movie.seasons) && movie.seasons.length > 0 ? (
        <div className="card-neon p-6">
          <h3 className="text-xl font-bold text-cyber-cyan mb-4">{text.seasonsAndEpisodes || "Seasons and episodes"}</h3>
          <div className="flex flex-wrap gap-2 mb-5">
            {movie.seasons
              .filter((season) => season.season_number > 0)
              .map((season) => (
                <button
                  key={season.id || season.season_number}
                  type="button"
                  onClick={() => onSeasonSelect && onSeasonSelect(season.season_number)}
                  className={`px-3 py-1 rounded-lg border text-sm ${
                    selectedSeason === season.season_number
                      ? "border-cyber-fuchsia text-cyber-fuchsia bg-cyber-fuchsia/10"
                      : "border-cyber-cyan/30 text-cyber-cyan"
                  }`}
                >
                  {text.season || "Season"} {season.season_number}
                </button>
              ))}
          </div>

          {seasonDetails?.episodes?.length ? (
            <div className="grid md:grid-cols-2 gap-3">
              {seasonDetails.episodes.map((episode) => (
                <div key={episode.id} className="rounded-xl border border-cyber-cyan/20 p-3 bg-cyber-darker/40">
                  <p className="text-cyber-cyan font-semibold">
                    {text.episode || "Episode"} {episode.episode_number}: {episode.name}
                  </p>
                  <p className="text-cyber-cyan/70 text-sm mt-1">
                    {episode.air_date || naText} - {episode.runtime ? `${episode.runtime} ${text.minutes || "min"}` : naText}
                  </p>
                  <p className="text-cyber-cyan/70 text-sm mt-2 line-clamp-3">{episode.overview || text.noOverview}</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-cyber-cyan/70">{text.noEpisodes || "No episodes found for this season."}</p>
          )}
        </div>
      ) : null}
    </div>
  );
}
