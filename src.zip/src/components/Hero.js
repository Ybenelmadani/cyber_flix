import React from "react";

export default function Hero({ title, subtitle }) {
  return (
    <div className="relative mb-12 rounded-3xl overflow-hidden bg-gradient-to-r from-purple-900/40 to-blue-900/40 border border-cyan-500/20">
      <div className="px-8 py-16 text-center">
        <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-cyan-400 to-fuchsia-400 bg-clip-text text-transparent">
          {title}
        </h1>
        <p className="text-lg md:text-xl text-cyan-300/80">{subtitle}</p>
      </div>
    </div>
  );
}