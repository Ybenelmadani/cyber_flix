import React from "react";
import { Play } from "lucide-react";

export default function MovieCard({
  movie,
  onClick,
  href = "#",
  yearLabel = "Year",
  unavailableLabel = "Unavailable",
}) {
  const title = movie.title || movie.name;
  const releaseDate = movie.release_date || movie.first_air_date;
  const posterUrl = movie.poster_path
    ? `https://image.tmdb.org/t/p/w500${movie.poster_path}`
    : "https://via.placeholder.com/400x600?text=No+Image";

  return (
    <a
      href={href}
      onClick={(event) => {
        event.preventDefault();
        if (onClick) {
          onClick();
        }
      }}
      className="group cursor-pointer text-left block"
    >
      <div className="relative aspect-[2/3] rounded-2xl overflow-hidden mb-3 bg-cyber-darker border border-cyber-cyan/20 group-hover:border-cyber-fuchsia/50 transition-all shadow-lg group-hover:shadow-cyber-fuchsia/20">
        <img
          src={posterUrl}
          alt={title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-cyber-dark/60 backdrop-blur-sm">
          <div className="w-16 h-16 rounded-full bg-cyber-gradient flex items-center justify-center shadow-lg transform scale-0 group-hover:scale-100 transition-transform">
            <Play className="w-8 h-8 text-white fill-white mr-1" />
          </div>
        </div>
      </div>
      <h3 className="font-bold text-cyber-cyan group-hover:text-cyber-fuchsia transition-colors line-clamp-1">
        {title}
      </h3>
      <p className="text-sm text-cyber-cyan/60">
        {yearLabel}: {releaseDate?.split("-")[0] || unavailableLabel}
      </p>
    </a>
  );
}
