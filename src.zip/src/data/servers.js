export const SERVERS = [
  'Server 1',
  'Server 2', 
  'Server 3',
  'Server 4'
];